import React, { PureComponent } from 'react'
import PhotoItem from '../components/PhotoItem'
import axios from 'axios'

class PhotoContainer extends PureComponent {
  state = {
    photos: []
  }

  componentDidMount() {
    axios
      .get('https://jsonplaceholder.typicode.com/photos?_start=0&_end=10')
      .then(response => {
        const newPhotos = response.data.map((photo) => {
          return {
            id: photo.id,
            title: photo.title,
            url: photo.url
          }
        })

        const newState = Object.assign({}, this.state, {
          photos: newPhotos
        })

        this.setState(newState)
      })
      .catch(error => console.log(error))
  }

  renderPhotos = (photo, index) => {
    return(
      <PhotoItem key={index} photo={photo}/>
    )
  }

  render() {
    const photos = this.state.photos

    return(
      <div className="photocontainer">
        { photos.map(this.renderPhotos) }
      </div>
    )
  }
}

export default PhotoContainer
