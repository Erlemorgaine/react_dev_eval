import photos from './photos'

export default {
  photos,
}
