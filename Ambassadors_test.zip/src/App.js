import React, { Component } from 'react';
import PhotoContainer from './containers/PhotoContainer'
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
        <PhotoContainer />
      </div>
    );
  }
}

export default App;
